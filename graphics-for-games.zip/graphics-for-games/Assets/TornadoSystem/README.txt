Tornado System Source Project

This project contains an example of a Tornado Physics in Unity 3D.

- Open 'TestScene' from Scenes folder to launch an example scene
- Press Play: use W,A,S,D keys to move the Tornado around
- Observe the Cubes are being pulled in and thrown by a Tornado (Orange Cubes are heavier so they don't fly around as easy)

sharpcoderblog.com